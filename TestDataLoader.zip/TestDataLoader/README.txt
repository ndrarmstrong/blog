﻿XAML Test Data Loader Sample Application by Nicholas Armstrong
Available online at http://nicholasarmstrong.com

This code is designed for illustration purposes only.  
Exception handling and other coding practices required for production
systems may have been ignored in order to reduce this code to its 
simplest possible form.

To run, press the 'Start Debugging' (F5) button, or press Ctrl-F5 to run without debugging.
Then, load one of the provided sample data files ('Load Data Model'), or generate a random 
data model by pressing the 'Add Location' and 'Add Device' buttons.  Save the data model by
pressing the 'Save Data Model' button and typing a file name.

	- Nicholas Armstrong, July 2009